package ar.edu.iua.soa.demo.exceptions;

public class InvalidPersonaException extends Exception
{
    private static final long serialVersionUID = -5086907350023253630L;

    public InvalidPersonaException() {
    }

    public InvalidPersonaException(String message) {
        super(message);
    }

    public InvalidPersonaException(Throwable cause) {
        super(cause);
    }

    public InvalidPersonaException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidPersonaException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);

    }
}
