package ar.edu.iua.soa.demo.repository;

import ar.edu.iua.soa.demo.model.Transaccion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;
import java.util.List;

public interface TransaccionRepository extends JpaRepository<Transaccion, Integer> {
    @Query(value="SELECT * FROM transaccion WHERE DATE(fecha_pago) = ?", nativeQuery=true)
    public List<Transaccion> byFecha(Date fecha_pago);
}
