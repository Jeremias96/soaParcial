package ar.edu.iua.soa.demo.business;

import ar.edu.iua.soa.demo.dto.PersonaDTO;
import ar.edu.iua.soa.demo.exceptions.InvalidPersonaException;
import ar.edu.iua.soa.demo.exceptions.LegajoExistenteException;
import ar.edu.iua.soa.demo.model.Persona;

public interface IPersonaBusiness {
    public Persona addPersona (Persona persona) throws InvalidPersonaException, LegajoExistenteException;
}
