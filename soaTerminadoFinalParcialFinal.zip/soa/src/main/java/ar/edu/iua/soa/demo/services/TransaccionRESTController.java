package ar.edu.iua.soa.demo.services;

import ar.edu.iua.soa.demo.business.ITransaccionBusiness;
import ar.edu.iua.soa.demo.dto.PersonaDTO;
import ar.edu.iua.soa.demo.exceptions.InvalidPersonaException;
import ar.edu.iua.soa.demo.exceptions.NotFoundException;
import ar.edu.iua.soa.demo.exceptions.TransaccionRechazadaException;
import ar.edu.iua.soa.demo.model.Persona;
import ar.edu.iua.soa.demo.model.Transaccion;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Constantes.URL_TRANSACCION)
public class TransaccionRESTController {

    @Autowired
    private ITransaccionBusiness transaccionBusiness;

    final static Logger log = Logger.getLogger("ListaRESTController.class");

    @RequestMapping(value = { "", "/" }, method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<Transaccion> addTransaccion(@RequestBody Persona persona){
        try{
            Transaccion tx = transaccionBusiness.addTransaccion(persona);
            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.set("location", "/pagos/" + tx.getId_transaccion());
            return new ResponseEntity<Transaccion>(tx, responseHeaders, HttpStatus.CREATED);
        }catch (InvalidPersonaException ex){
            log.error("No existe una persona con el legajo: " + persona.getLegajo());
            return new ResponseEntity<Transaccion>(HttpStatus.NOT_ACCEPTABLE);
        }catch (TransaccionRechazadaException ex){
            log.error("No se ha aprobado la transaccion");
            return new ResponseEntity<Transaccion>(HttpStatus.NOT_ACCEPTABLE);
        }catch (Exception ex) {
            return new ResponseEntity<Transaccion>(HttpStatus.NOT_FOUND);
        }
    }

    @RequestMapping(value = { "/verPagos" }, method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<Transaccion>> getTransaccionesPorFecha(
            @RequestParam(value = "fecha", defaultValue = "*") String fecha) {
        try {
            return new ResponseEntity<List<Transaccion>>(transaccionBusiness.getTransaccionesFecha(fecha), HttpStatus.OK);
        } catch (NotFoundException ex) {
            log.error("No se ha encontrado transacciones a la fecha: " + fecha);
            return new ResponseEntity<List<Transaccion>>(HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return new ResponseEntity<List<Transaccion>>(HttpStatus.NOT_FOUND);
        }
    }

    @RequestMapping(value = { "/payAll" }, method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<List<Transaccion>> payAll(){
        try {
            log.info("Todas las cuentas pagadas");
            return new ResponseEntity<List<Transaccion>>(transaccionBusiness.payAll(), HttpStatus.OK);
        }catch (TransaccionRechazadaException ex){
            log.error("No se ha aprobado la transaccion");
            return new ResponseEntity<List<Transaccion>>(HttpStatus.NOT_ACCEPTABLE);
        }catch (Exception ex) {
            return new ResponseEntity<List<Transaccion>>(HttpStatus.NOT_FOUND);
        }
    }
}
