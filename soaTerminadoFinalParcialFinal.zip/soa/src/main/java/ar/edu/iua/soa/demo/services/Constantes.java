package ar.edu.iua.soa.demo.services;

public final class Constantes {
    public static final String URL_TRANSACCION="/api/pagos";
    public static final String URL_PERSONA="/api/persona";
}
