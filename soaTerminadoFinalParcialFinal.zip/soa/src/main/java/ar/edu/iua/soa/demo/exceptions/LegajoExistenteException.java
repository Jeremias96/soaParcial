package ar.edu.iua.soa.demo.exceptions;

public class LegajoExistenteException extends Exception{
    public LegajoExistenteException() {
        super();
    }

    public LegajoExistenteException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public LegajoExistenteException(String message, Throwable cause) {
        super(message, cause);
    }

    public LegajoExistenteException(String message) {
        super(message);
    }

    public LegajoExistenteException(Throwable cause) {
        super(cause);
    }

}
