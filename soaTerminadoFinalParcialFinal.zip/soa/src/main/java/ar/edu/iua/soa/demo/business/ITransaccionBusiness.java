package ar.edu.iua.soa.demo.business;

import ar.edu.iua.soa.demo.dto.PersonaDTO;
import ar.edu.iua.soa.demo.exceptions.InvalidPersonaException;
import ar.edu.iua.soa.demo.exceptions.NotFoundException;
import ar.edu.iua.soa.demo.exceptions.TransaccionRechazadaException;
import ar.edu.iua.soa.demo.model.Persona;
import ar.edu.iua.soa.demo.model.Transaccion;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

public interface ITransaccionBusiness {
    public Transaccion addTransaccion (Persona persona) throws InvalidPersonaException, TransaccionRechazadaException, IOException;

    public List<Transaccion> getTransaccionesFecha(String fecha) throws ParseException, NotFoundException;

    public List<Transaccion> payAll() throws TransaccionRechazadaException, IOException;
}
